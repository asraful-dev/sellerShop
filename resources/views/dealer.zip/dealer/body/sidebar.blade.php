@php
$id = Auth::user()->id;
$dealerId = App\Models\User::find($id);
$status = $dealerId->active_status; 
@endphp
<div class="sidebar-wrapper" data-simplebar="true">
   <div class="sidebar-header">
      <div>
         <img src="{{ asset('adminbackend/assets/images/logo-icon.png') }}" class="logo-icon" alt="logo icon">
      </div>
      <div>
         <h4 class="logo-text">Dealer</h4>
      </div>
      <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
      </div>
   </div>
   <!--navigation-->
   <ul class="metismenu" id="menu">
      <li>
         <a href="{{ route('dealer.dashobard') }}">
            <div class="parent-icon"><i class='bx bx-home-circle'></i>
            </div>
            <div class="menu-title">Dashboard</div>
         </a>
      </li>
      <li>
         <a href="#" class="has-arrow">
            <div class="parent-icon"><i class='lni lni-fresh-juice'></i>
            </div>
            <div class="menu-title">Product Manage </div>
         </a>
         <ul>
            <li> <a href="{{ route('dealer.product.list') }}"><i class="bx bx-right-arrow-alt"></i>All Product</a>
            </li>
            <li> <a href="{{ route('dealer.product.transfer') }}"><i class="bx bx-right-arrow-alt"></i>Transfer Product</a>
            </li>
            <li> <a href="{{ route('dealer.customer.sale.product') }}"><i class="bx bx-right-arrow-alt"></i>Customer Sale Product</a>
            </li>
         </ul>
      </li>
      <li>
         <a href="#" class="has-arrow">
            <div class="parent-icon"><i class='lni lni-fresh-juice'></i>
            </div>
            <div class="menu-title">All Balance Request</div>
         </a>
         <ul>
            <li> <a href="{{ route('dealer.usd.request') }}"><i class="bx bx-right-arrow-alt"></i>Bank Request</a>
            </li>
            <li> <a href="{{ route('dealer.bkash.request') }}"><i class="bx bx-right-arrow-alt"></i>Bkash Request</a>
            </li>
            <li> <a href="{{ route('dealer.nagad.request') }}"><i class="bx bx-right-arrow-alt"></i>Nagad Request</a>
            </li>
            <li> <a href="{{ route('dealer.rocket.request') }}"><i class="bx bx-right-arrow-alt"></i>Rocket Request</a>
            </li>
            <li> <a href="{{ route('dealer.balance.request.list') }}"><i class="bx bx-right-arrow-alt"></i>My Balance Request List</a>
            </li>
         </ul>
      </li>
      <li>
         <a href="#" class="has-arrow">
            <div class="parent-icon"><i class='lni lni-fresh-juice'></i>
            </div>
            <div class="menu-title">All Withdraw Request</div>
         </a>
         <ul>
            <li> <a href="{{ route('dealer.usd.withdraw.request') }}"><i class="bx bx-right-arrow-alt"></i>Bank Request</a>
            </li>
            <li> <a href="{{ route('dealer.bkash.withdraw.request') }}"><i class="bx bx-right-arrow-alt"></i>Bkash Request</a>
            </li>
            <li> <a href="{{ route('dealer.nagad.withdraw.request') }}"><i class="bx bx-right-arrow-alt"></i>Nagad Request</a>
            </li>
            <li> <a href="{{ route('dealer.rocket.withdraw.request') }}"><i class="bx bx-right-arrow-alt"></i>Rocket Request</a>
            </li>
            <li> <a href="{{ route('dealer.withdraw.request.list') }}"><i class="bx bx-right-arrow-alt"></i>My Withdraw Request List</a>
            </li>
         </ul>
      </li>
      {{-- <li>
         <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="bx bx-cart"></i>
            </div>
            <div class="menu-title"> Order Manage </div>
         </a>
         <ul>
            <li> <a href="#"><i class="bx bx-right-arrow-alt"></i>Vendor Order</a>
            </li>
            <li> <a href="#"><i class="bx bx-right-arrow-alt"></i>Return Order</a>
            </li>
            <li> <a href="#"><i class="bx bx-right-arrow-alt"></i>Complete Return Order</a>
            </li>
         </ul>
      </li>
      <li>
         <a href="javascript:;" class="has-arrow">
            <div class="parent-icon"><i class="lni lni-indent-increase"></i>
            </div>
            <div class="menu-title"> Review Manage </div>
         </a>
         <ul>
            <li> <a href="#"><i class="bx bx-right-arrow-alt"></i>All Review</a>
            </li>
         </ul>
      </li> --}}
   </ul>
   <!--end navigation-->
</div>